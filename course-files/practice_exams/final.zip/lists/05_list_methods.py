sentence = 'The quick brown fox jumps over the lazy dog'
words = sentence.split(' ')
print('-'.join(words))