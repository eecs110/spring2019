my_list = ['blue', 'purple', 'red', 'green', 'black']
print(my_list[2:3])
print(my_list[1:])
print(my_list[0:1] + my_list[4:])