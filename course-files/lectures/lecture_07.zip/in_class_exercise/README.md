---
layout: default
title: While Loops Exercise 1
nav_exclude: True
---

# Exercise 1: Instructions
Instructions available in [the Google Doc](https://docs.google.com/document/d/1RSd-NsjrZjjMX4mO9LfNFzQgFmJVA6KVLYYJXgGQDWc/edit?usp=sharing)