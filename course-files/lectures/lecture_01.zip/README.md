---
layout: default
title: Lecture 01 Materials
nav_exclude: True
---

# Lecture 01 Materials

* <a href="https://docs.google.com/presentation/d/1SHTEbdjPrZm5JLkB1qo614mFUXUP3ZudoGGSMnOUyQY/edit?usp=sharing" target="_blank">Slides 00: Intro to the Course</a>
* [lecture_01.zip](../lecture_01.zip)