# http://effbot.org/tkinterbook/scale.htm
from tkinter import Tk, Scale
import threader
import psonic


root = Tk()

# riff:
def play_base_beat(tempo:float=60, sample=psonic.DRUM_BASS_SOFT):
    speed = 60 / tempo
    psonic.sample(sample)
    psonic.sleep(speed)

def kill_threads_and_close():
    controller.stop()
    root.destroy()


# thread:
controller = threader.SonicPiController(tempo=60, riff=play_base_beat)
controller.start(sample=psonic.DRUM_BASS_SOFT)


def tempo_controller(val):
    controller.tempo = 60 + int(val) * 10

w = Scale(root, from_=0, to=10, resolution=1, command=tempo_controller)
w.pack()

root.protocol('WM_DELETE_WINDOW', kill_threads_and_close)

root.mainloop()