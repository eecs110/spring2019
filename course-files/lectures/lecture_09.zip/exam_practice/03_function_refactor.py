# TODO: Refactor this into a function
print('''
Dear Meredith,

Thank you for donating $50 to the Southern Poverty Law Center. We really appreciate donors like
you. Because of your support, you are eligible to become a bronze-level supporter. As a token of
our appreciation, please accept this coffee mug.

We look forward to your continued sponsorship.

Sincerely,

SPLC
''')

print('''
Dear Toby,

Thank you for donating $150 to the Southern Poverty Law Center. We really appreciate donors like
you. Because of your support, you are eligible to become a silver-level supporter. As a token of
our appreciation, please accept this engraved pen.

We look forward to your continued sponsorship.

Sincerely,

SPLC
''')


print('''
Dear Tomar,

Thank you for donating $250 to the Southern Poverty Law Center. We really appreciate donors like
you. Because of your support, you are eligible to become a gold-level supporter. As a token of
our appreciation, please accept this T-Shirt.

We look forward to your continued sponsorship.

Sincerely,

SPLC
''')