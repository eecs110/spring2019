# ----------------------------------------------------
# 1. functions with no parameters and no return value
# ----------------------------------------------------
# function definition:
def say_hello():
    print('Hello there!')
    print('How are you this morning?')

# function call (always does the same thing):
say_hello()
say_hello()
say_hello()
say_hello()

# result = say_hello()
# print('No return value:', result)