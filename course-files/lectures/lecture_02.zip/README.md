---
layout: default
title: Lecture 02 Materials
nav_exclude: True
---

# Lecture 02 Materials

* <a href="#" target="_blank">Slides 01: Hardware and software</a>
* <a href="#" target="_blank">Slides 02: Expressions, variables, and statements</a>
* [lecture_02.zip](../lecture_02.zip)
