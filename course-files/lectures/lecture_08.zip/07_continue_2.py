message = 'this is a test'
# Challenge: replace all of the spaces with asteriks using a 
# for loop and a continue statement