---
layout: default
title: Project 2
nav_exclude: True
---

# Project 2 Instructions
Pick *ONE* of the following <a href="https://docs.google.com/document/d/1_JgorjCv7DFUJra9Duop3zRBjkkHymp7WwlUWfI1JX8/edit?usp=sharing" target="_blank">options</a> for project 2, which is worth 40 points. 

There are up to 20 points extra credit. You may work in groups of 2-3.

## Due
**Due Tu, June 11 at 11:59PM**. Late penaly of 20% for projects that are 48 hours late. No projects will be accepted after that.