---
layout: default
title: Project 2
nav_exclude: True
---

# Project 2 Instructions
Pick *ONE* of the following <a href="https://docs.google.com/document/d/1_JgorjCv7DFUJra9Duop3zRBjkkHymp7WwlUWfI1JX8/edit?usp=sharing" target="_blank">options</a> for project 2, which is worth 40 points. 

There are up to 20 points extra credit. You may work in groups of 2-3.

## Option 1: Restaurant Recommender
Note: this is one way of doing this and includes some extra credit options. Feel free to do it *your way!
<iframe src="https://northwestern.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=2ad3f91d-a2c5-4876-837e-aa5b00ee9e18&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen allow="autoplay"></iframe>

## Option 2: Music Recommender
Note: this is one way of doing this and includes some extra credit options. Feel free to do it *your way!
<iframe src="https://northwestern.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=45231dc9-9925-4295-9445-aa5b00ef6414&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen allow="autoplay"></iframe>

## Due
**Due Tu, June 11 at 11:59PM**. Late penaly of 20% for projects that are 48 hours late. No projects will be accepted after that.