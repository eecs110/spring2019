---
layout: default
title: Project 1
nav_exclude: True
---

# Project 1 Instructions
Pick *ONE* of the following options for project 1, which is worth 40 points. 

1. <a href="https://docs.google.com/document/d/19ro-yIcBk1MkGbRcWdFRXCobkM_OW1h-VqVy95coUVM/edit?usp=sharing" target="_blank">Graphics Track Instructions</a>
2. <a href="https://docs.google.com/document/d/1rjjk1LpQ7fAilh5o448_yOG5pk8mSq4PkK7jk4Rm2Fg/edit?usp=sharing" target="_blank">Audio Track Instructions</a>

## Due
**Due Th, May 16 at 11:59PM**. Late penaly of 20% for projects that are 48 hours late. No projects will be accepted after that.

