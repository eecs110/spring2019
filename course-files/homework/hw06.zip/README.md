---
layout: default
title: Homework 6
nav_exclude: True
---

# Homework 6 Instructions
* Due: Tu, June 4 (11:59PM)
* Please complete AT LEAST 20 points of <a href="course-files/projects/project_02/README">Project 2</a>.
