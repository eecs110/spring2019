---
layout: default
title: Homework 2
nav_exclude: True
---

# Homework 2 Instructions
Pick *ONE* of the following options for homework 2. Whichever 
option you choose, you'll be sticking with it for the next 4-5 weeks. The files that are needed for homework 2 can be downloaded [here](../hw02.zip).

1. <a href="https://docs.google.com/document/d/1SPzQEW2b6cDOdFvI8xHMufwnf3BwehjYeOnRrSR-KEU/edit?usp=sharing" target="_blank">Graphics Track Instructions</a>
2. <a href="https://docs.google.com/document/d/1iN793WQsAOXCEpCTaoK80JlfmiYCZ1SXBhAicdKfxSs/edit?usp=sharing" target="_blank">Audio Track Instructions</a>

## Due
April 16 at 11:59PM