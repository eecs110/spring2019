---
layout: default
title: Homework 3
nav_exclude: True
---

# Homework 4 Instructions
Pick *ONE* of the following options for homework 4. The files that are needed for homework 4 can be downloaded [here](../hw04.zip).

1. <a href="https://docs.google.com/document/d/1LrqGM5tOtxnr19wtv8KvHWsbLFouD___iJq0gaJWrPI/edit?usp=sharing" target="_blank">Graphics Track Instructions</a>
2. <a href="https://docs.google.com/document/d/1uQG6TL0ztPwuswYXoe0B0_vWkCyfqlOM4NdvCwlWvtQ/edit?usp=sharing" target="_blank">Audio Track Instructions</a>

## Due
May 2 at 11:59PM