---
layout: default
title: Homework 1
nav_exclude: True
---

# Homework 1 Instructions
Install Python and Anaconda, and complete the 9 exercises. Instructions [here](https://docs.google.com/document/d/15gCDQewmyxbK_Oeb1EuPdVWhMIlWb-HyQdkPu7fg6Qo/edit#).
