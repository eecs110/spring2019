---
layout: default
title: Homework 1
nav_exclude: True
---

# Homework 1 Instructions
Install Python and Anaconda, and complete the 9 exercises. 

* Instructions available in [the Google Doc](https://docs.google.com/document/d/15gCDQewmyxbK_Oeb1EuPdVWhMIlWb-HyQdkPu7fg6Qo/edit#)
* Due on Tuesday, April 9th, at 11:59PM
* Download the starter [main.py](main.py) file
