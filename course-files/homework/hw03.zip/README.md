---
layout: default
title: Homework 3
nav_exclude: True
---

# Homework 3 Instructions
Pick *ONE* of the following options for homework 3. The files that are needed for homework 3 can be downloaded [here](../hw03.zip).

1. <a href="https://docs.google.com/document/d/1CrNBG1MkYatwHfdtJliNjJZByeQQftKRCnOqBaADnX4/edit?usp=sharing" target="_blank">Graphics Track Instructions</a>
2. <a href="https://docs.google.com/document/d/1BAAoC5SGmGs3KmYvc0DszBjpZ8XKPoajLBDGxMUnlC4/edit?usp=sharing" target="_blank">Audio Track Instructions</a>

## Due
April 23 at 11:59PM