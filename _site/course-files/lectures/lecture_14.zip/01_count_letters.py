# TODO: Find out how many instances of each letter exist:
word = 'supercalifragilisticexpialidocious'