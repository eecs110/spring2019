## FIXED VERSION
def sum(num1, num2):
    return num1 + num2

# ## BROKEN VERSION
# def sum(num1, num2):
#     num1 + num2

result = sum(5, 7)
print('The sum is:', result)
## End Example 2