---
layout: default
title: Practice Exams
nav_exclude: True
---

# Exam 1 Practice

* <a href="https://drive.google.com/open?id=1LrlDxl4MJoO0O91Xd-0gvWh_M_713uLx3LxSb6kJV6E" target="_blank">Study Guide</a>
* <a href="https://drive.google.com/open?id=1pTOEq5-IrZA9c1agnNNgpKjohD-HyJu8An88bo7MF70" target="_blank">Practice Exam 1</a>
   * <a href="https://drive.google.com/open?id=14SaUUiaN_z6T569ygovmQazh1roabHgT5WnA99hu8Ic" target="_blank">solutions</a>
* <a href="https://drive.google.com/open?id=1c2jkBcVebg1-1g75iPk43_NHIKJsW89MVroWXCu2fLQ" target="_blank">Practice Exam 2</a>
   * <a href="https://drive.google.com/open?id=1JwhJ6XxxpF1N8HU7EppuPB4Lgy2LKv_rBaskmnd7SHc" target="_blank">solutions</a>
* <a href="https://drive.google.com/open?id=17BbkOHrAmCDq7QSFRSiYOUN_yYyzd4rKZhvLkL2-RYA" target="_blank">Additional Practice</a>
   * <a href="../midterm.zip">solutions</a>