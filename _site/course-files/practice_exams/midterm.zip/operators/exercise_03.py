# What will the output of this program be?
result = 16 + 20 % 7 % 5 / 2
print(result)
# if you ever want to know what type of data you have, 
# use the built-in type() function:
# IMPORTANT: Any time you use the division operator, the result is a float
print(type(result))     # float