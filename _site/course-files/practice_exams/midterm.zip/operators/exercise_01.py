# What will the output of this program be?
result = 16 - 2 * 5 // 3 + 1
print(result)
print(type(result))  # int